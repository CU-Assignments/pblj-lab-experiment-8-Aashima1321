CREATE DATABASE EmployeesDB;

USE EmployeesDB;

CREATE TABLE employees (
    id INT PRIMARY KEY,
    name VARCHAR(100),
    position VARCHAR(100),
    department VARCHAR(50)
);

INSERT INTO employees (id, name, position, department) 
VALUES (1, 'John Doe', 'Manager', 'HR'),
       (2, 'Jane Smith', 'Developer', 'IT'),
       (3, 'Alice Brown', 'Analyst', 'Finance');
       select * from employees
       
