-- Create the database
CREATE DATABASE StudentPortalDB;

-- Use the newly created database
USE StudentPortalDB;

-- Create the attendance table
CREATE TABLE attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_name VARCHAR(100),
    date DATE,
    status VARCHAR(10)
);

-- Optional: Insert sample data
INSERT INTO attendance (student_name, date, status)
VALUES 
    ('John Doe', '2025-04-14', 'Present'),
    ('Jane Smith', '2025-04-14', 'Absent'),
    ('Alice Brown', '2025-04-14', 'Present');
